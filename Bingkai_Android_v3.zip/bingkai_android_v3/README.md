# Bingkai untuk Android (v3)

Aplikasi Android untuk mengunduh video dan foto TikTok. Semuanya jalan di dalam HP, tanpa server.

## Cara kerja

- Python (Flask + yt-dlp) berjalan di dalam aplikasi lewat [Chaquopy](https://chaquo.com/chaquopy/).
- Tampilannya WebView yang membuka server lokal itu, jadi tidak ada masalah CORS.
- File disimpan ke galeri: video di `Movies/Bingkai`, foto di `Pictures/Bingkai`, ZIP di `Download/Bingkai`.
- Video 4K: kalau kreator mengunggah 4K, kamu dapat **4K asli**. Kalau tidak, ada pilihan **4K (bukan asli)** yang memperbesar video dengan chip video HP (Media3 Transformer). Foto diperbesar dengan Pillow.
- Tiap pilihan kualitas video sekarang menampilkan **fps** (30/60) dan **bitrate asli** (kbps), supaya kelihatan mana yang beneran detail tajam, bukan cuma resolusi besar tapi terkompresi.
- Bisa dipakai dari menu **Bagikan** TikTok: Bagikan, pilih Bingkai, link langsung dicek.

Syarat: Android 10 ke atas.

## Upscale AI (Real-ESRGAN) — tidak aktif di APK biasa

Ada opsi backend "AI tajam 2x" yang memperbesar video pakai Real-ESRGAN (per-frame,
betulan menambah detail, bukan cuma diperbesar/blur seperti Media3). Ini butuh binary
`realesrgan-ncnn-vulkan` yang **tidak** ikut dipaketkan di APK (ukurannya besar dan
build-nya rumit untuk Chaquopy), jadi di APK normal opsi ini otomatis tidak muncul —
fitur lain tetap jalan seperti biasa.

Kalau mau mencobanya di HP, pakai jalur **Termux** di bawah dan install binary
Real-ESRGAN-ncnn-vulkan versi Linux ARM64 secara manual, lalu jalankan `app.py` yang
sama seperti di komputer.

## Cara membuat APK dari HP (tanpa komputer)

APK dibuat gratis oleh GitHub Actions. Kamu hanya perlu browser HP.

1. Buka github.com, daftar atau masuk, lalu buat **repository baru** (New repository, nama bebas, Public, centang "Add a README").
2. Di repo itu: **Add file, Upload files**, pilih `Bingkai_Android_v3.zip` (jangan diekstrak), lalu **Commit changes**.
3. **Add file, Create new file**. Di kolom nama ketik persis `.github/workflows/build.yml`, tempel seluruh isi file `build.yml`, lalu **Commit changes**.
4. Buka tab **Actions**. Proses berjalan sendiri, sekitar 10 sampai 15 menit. Kalau tidak jalan sendiri: pilih "Build APK Bingkai", lalu **Run workflow**.
5. Kalau sudah centang hijau, buka **Releases** di halaman utama repo, lalu ketuk `app-debug.apk` untuk mengunduh. (Cadangan: buka run-nya, bagian Artifacts, `Bingkai-APK`; file itu berbentuk zip, ekstrak dulu.)
6. Buka APK-nya dan izinkan "pasang dari sumber ini". Play Protect mungkin memperingatkan karena aplikasi ini tidak dari Play Store; itu normal untuk APK buatan sendiri.

## Kalau TikTok berubah dan link tiba-tiba gagal

yt-dlp diambil versi terbaru setiap kali build. Jalankan ulang build (Actions, Run workflow), pasang APK baru di atas yang lama.

## Kalau build gagal

Buka run yang gagal (tanda silang merah), ketuk langkah **Build APK**, salin baris error-nya, dan kirim ke Claude. Proyek ini belum pernah dibuild sebelum dikirim, jadi kesalahan di build pertama mungkin terjadi.

## Cadangan: jalan lewat Termux (tanpa APK)

Install Termux dari F-Droid, lalu:

```bash
pkg install python ffmpeg python-pillow
pip install flask requests yt-dlp
# salin app.py dan folder static dari proyek web (v1) ke Termux, lalu:
python app.py
```

Buka `http://localhost:5000` di Chrome.

## Struktur

```
app/src/main/python/app.py            backend Flask + yt-dlp
app/src/main/python/android_entry.py  menyalakan server dari Kotlin
app/src/main/assets/index.html        tampilan
app/src/main/java/.../MainActivity.kt WebView, simpan ke galeri, upscale 4K
app/build.gradle                      dependensi (Chaquopy, Media3) dan paket Python
```

## Catatan

- Unduh hanya konten milikmu atau yang sudah diizinkan pembuatnya. Mengunduh konten orang lain bisa melanggar ketentuan TikTok dan hak cipta.
- Proses 4K memakai encoder HP. Kalau HP tidak mendukung encode 4K, hasilnya lebih kecil dan aplikasi akan memberi tahu.
- Biarkan aplikasi tetap terbuka selama proses memperbesar video ke 4K.
