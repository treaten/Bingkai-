package id.bingkai.app

import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.URL
import kotlin.concurrent.thread

/**
 * Bingkai: WebView yang menampilkan UI dari server Flask lokal (Python via Chaquopy).
 * - Unduhan dari server disimpan ke galeri (Movies/Pictures/Downloads, folder "Bingkai").
 * - Upscale video ke 4K dikerjakan di sini dengan Media3 Transformer (encoder hardware HP).
 * - Bisa menerima link lewat menu Bagikan dari TikTok.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var pendingShare: String? = null
    private var pageReady = false

    companion object {
        @Volatile
        private var serverBase: String? = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            // Hanya halaman lokal yang boleh dibuka, supaya jembatan JS tidak terbuka untuk situs lain.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return request.url.host != "127.0.0.1"
            }

            override fun onPageFinished(view: WebView, url: String) {
                if (url.startsWith("http://127.0.0.1")) {
                    pageReady = true
                    deliverShare()
                }
            }
        }
        web.setDownloadListener { url, _, contentDisposition, mimetype, _ ->
            saveFromUrl(url, contentDisposition, mimetype)
        }

        web.loadData(
            "<body style='font-family:sans-serif;padding:32px'>Memulai Bingkai…</body>",
            "text/html",
            "utf-8"
        )
        pendingShare = sharedText(intent)
        startBackend()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        pendingShare = sharedText(intent)
        deliverShare()
    }

    // ------------------------------------------------------------------ server Python

    private fun startBackend() {
        serverBase?.let { web.loadUrl("$it/"); return }
        val html = assets.open("index.html").bufferedReader().use { it.readText() }
        thread {
            try {
                val port = ServerSocket(0).use { it.localPort }
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                Python.getInstance().getModule("android_entry").callAttr("start", port, html)
                val base = "http://127.0.0.1:$port"
                repeat(120) {
                    try {
                        val c = URL("$base/health").openConnection() as HttpURLConnection
                        c.connectTimeout = 500
                        c.readTimeout = 500
                        if (c.responseCode == 200) {
                            serverBase = base
                            runOnUiThread { web.loadUrl("$base/") }
                            return@thread
                        }
                    } catch (_: Exception) {
                        // server belum siap, coba lagi
                    }
                    Thread.sleep(250)
                }
                showError("Server internal tidak menyala dalam 30 detik.")
            } catch (e: Exception) {
                showError(e.message ?: e.toString())
            }
        }
    }

    private fun showError(message: String) {
        runOnUiThread {
            val safe = message.replace("<", "&lt;")
            web.loadData(
                "<body style='font-family:sans-serif;padding:32px'><h3>Bingkai gagal dimulai</h3><p>$safe</p></body>",
                "text/html",
                "utf-8"
            )
        }
    }

    // ------------------------------------------------------------------ berbagi link

    private fun sharedText(i: Intent?): String? =
        if (i?.action == Intent.ACTION_SEND && i.type == "text/plain") i.getStringExtra(Intent.EXTRA_TEXT) else null

    private fun deliverShare() {
        val text = pendingShare ?: return
        if (!pageReady) return
        pendingShare = null
        runOnUiThread {
            web.evaluateJavascript("window.setSharedLink(${JSONObject.quote(text)})", null)
        }
    }

    // ------------------------------------------------------------------ jembatan JS

    inner class Bridge {
        @JavascriptInterface
        fun paste(): String {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return ""
            if (clip.itemCount == 0) return ""
            return clip.getItemAt(0).coerceToText(this@MainActivity)?.toString() ?: ""
        }

        @JavascriptInterface
        fun upscale(url: String, width: Int, height: Int, name: String) {
            upscaleVideo(url, width, height, name)
        }
    }

    private fun toast(message: String) {
        runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    }

    private fun jsResult(ok: Boolean, message: String) {
        runOnUiThread {
            web.evaluateJavascript("window.onNativeUpscale($ok, ${JSONObject.quote(message)})", null)
        }
    }

    // ------------------------------------------------------------------ simpan ke galeri

    private fun isLocal(url: String) = Uri.parse(url).host == "127.0.0.1"

    private fun resolveMime(name: String, hint: String?): String {
        val h = hint?.substringBefore(';')?.trim()?.lowercase()
        if (!h.isNullOrEmpty() && h != "application/octet-stream") return h
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    /** Menyalin stream ke MediaStore dan mengembalikan lokasi yang mudah dibaca. */
    private fun saveStream(input: InputStream, name: String, mime: String): String {
        val collection: Uri
        val dir: String
        when {
            mime.startsWith("video/") -> {
                collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                dir = Environment.DIRECTORY_MOVIES
            }
            mime.startsWith("image/") -> {
                collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                dir = Environment.DIRECTORY_PICTURES
            }
            else -> {
                collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                dir = Environment.DIRECTORY_DOWNLOADS
            }
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$dir/Bingkai")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(collection, values)
            ?: throw IllegalStateException("Tidak bisa membuat file di penyimpanan")
        contentResolver.openOutputStream(uri)!!.use { out -> input.copyTo(out) }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
        return "$dir/Bingkai"
    }

    private fun saveFromUrl(url: String, contentDisposition: String?, mimetype: String?) {
        if (!isLocal(url)) return
        thread {
            try {
                val name = URLUtil.guessFileName(url, contentDisposition, mimetype)
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 10_000
                conn.readTimeout = 600_000
                val mime = resolveMime(name, conn.contentType ?: mimetype)
                val where = conn.inputStream.use { saveStream(it, name, mime) }
                toast("Tersimpan di $where")
            } catch (e: Exception) {
                toast("Gagal menyimpan: ${e.message}")
            }
        }
    }

    // ------------------------------------------------------------------ upscale video ke 4K

    private fun upscaleVideo(url: String, width: Int, height: Int, name: String) {
        if (!isLocal(url)) return
        thread {
            val stamp = System.currentTimeMillis()
            val src = File(cacheDir, "src_$stamp.mp4")
            val out = File(cacheDir, "out_$stamp.mp4")
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.readTimeout = 600_000
                conn.inputStream.use { i -> src.outputStream().use { o -> i.copyTo(o) } }
            } catch (e: Exception) {
                src.delete()
                jsResult(false, "Gagal mengambil video sumber: ${e.message}")
                return@thread
            }
            runOnUiThread {
                try {
                    val presentation = Presentation.createForWidthAndHeight(
                        width, height, Presentation.LAYOUT_SCALE_TO_FIT
                    )
                    val item = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(src)))
                        .setEffects(
                            Effects(listOf<AudioProcessor>(), listOf<Effect>(presentation))
                        )
                        .build()
                    val transformer = Transformer.Builder(this)
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .addListener(object : Transformer.Listener {
                            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                                finishUpscale(src, out, width, height, name)
                            }

                            override fun onError(
                                composition: Composition,
                                exportResult: ExportResult,
                                exportException: ExportException
                            ) {
                                src.delete()
                                out.delete()
                                jsResult(false, "Gagal memperbesar video: ${exportException.message}")
                            }
                        })
                        .build()
                    transformer.start(item, out.absolutePath)
                } catch (e: Exception) {
                    src.delete()
                    out.delete()
                    jsResult(false, "Gagal memulai proses 4K: ${e.message}")
                }
            }
        }
    }

    private fun finishUpscale(src: File, out: File, width: Int, height: Int, name: String) {
        thread {
            try {
                val mmr = MediaMetadataRetriever()
                mmr.setDataSource(out.absolutePath)
                val rw = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val rh = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                mmr.release()
                val where = out.inputStream().use { saveStream(it, name, "video/mp4") }
                // Beberapa HP tidak bisa encode 4K; Media3 lalu memilih ukuran terbesar yang didukung.
                val note = if (minOf(rw, rh) in 1 until minOf(width, height))
                    " HP kamu hanya mendukung ${rw}×${rh}, jadi hasilnya belum 4K penuh." else ""
                jsResult(true, "Tersimpan di $where.$note")
            } catch (e: Exception) {
                jsResult(false, "Gagal menyimpan hasil: ${e.message}")
            } finally {
                src.delete()
                out.delete()
            }
        }
    }
}
