"""
Bingkai: pengunduh video dan foto TikTok (Flask + yt-dlp).

Dua mode:
  - Komputer/server: python app.py  ->  http://localhost:5000 (ffmpeg untuk upscale 4K)
  - Aplikasi Android: dijalankan oleh android_entry.py di dalam APK (Chaquopy).
    Di mode ini upscale video 4K dikerjakan Kotlin (Media3 Transformer), bukan ffmpeg.

Alur:
  POST /api/info     -> cek link, kembalikan daftar kualitas (video) atau jumlah foto
  POST /api/prepare  -> siapkan file (unduh, opsional upscale 4K), kembalikan URL unduhan
  GET  /api/file/<t> -> kirim file hasil prepare
  GET  /api/preview  -> proxy thumbnail/foto supaya tidak diblokir hotlink
"""
import io
import ipaddress
import json
import mimetypes
import os
import re
import secrets
import shutil
import socket
import subprocess
import tempfile
import time
import zipfile
from collections import defaultdict, deque
from http.cookiejar import MozillaCookieJar
from urllib.parse import urljoin, urlparse

import requests
import yt_dlp
from flask import Flask, Response, jsonify, request, send_file, send_from_directory

try:
    from PIL import Image, ImageFilter
except ImportError:  # foto tetap bisa diunduh, hanya tanpa upscale 4K
    Image = None

# --------------------------------------------------------------------------
# Konfigurasi (bisa diubah lewat environment variable)
# --------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ANDROID = os.environ.get("BINGKAI_ANDROID") == "1"
INDEX_HTML = None  # di Android, halaman diberikan oleh Kotlin lewat android_entry.start()


def _work_dir():
    try:
        base = tempfile.gettempdir()
    except Exception:  # beberapa lingkungan Android tidak punya folder temp standar
        base = os.path.expanduser("~")
    return os.path.join(base, "bingkai_jobs")


WORK_DIR = _work_dir()
os.makedirs(WORK_DIR, exist_ok=True)

COOKIE_FILE = os.environ.get("TIKTOK_COOKIES", "")  # path cookies.txt (opsional)
MAX_VIDEO_SECONDS = int(os.environ.get("MAX_VIDEO_SECONDS", "900"))
MAX_UPSCALE_SECONDS = int(os.environ.get("MAX_UPSCALE_SECONDS", "120"))
RATE_LIMIT = int(os.environ.get("RATE_LIMIT_PER_MIN", "1000" if ANDROID else "30"))
STRICT_HOST_CHECK = os.environ.get("STRICT_HOST_CHECK", "0" if ANDROID else "1") == "1"
JOB_TTL = 15 * 60  # file hasil disimpan 15 menit
CACHE_TTL = 10 * 60
FFMPEG = shutil.which("ffmpeg")
NATIVE_UPSCALE = ANDROID and not FFMPEG  # upscale video dikerjakan aplikasi Android
CAN_UPSCALE = bool(FFMPEG) or NATIVE_UPSCALE

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)
HEADERS = {
    "User-Agent": UA,
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.tiktok.com/",
}
PAGE_HOSTS = ("tiktok.com",)
CDN_HOSTS = (
    "tiktokcdn.com", "tiktokcdn-us.com", "tiktokcdn-eu.com", "tiktokv.com",
    "tiktokv.us", "tiktokv.eu", "byteoversea.com", "ibytedtos.com",
    "ibyteimg.com", "muscdn.com", "tiktok.com",
)
IMAGE_EXT = {
    "image/jpeg": ".jpg", "image/jpg": ".jpg", "image/png": ".png",
    "image/webp": ".webp", "image/heic": ".heic", "image/avif": ".avif",
}
TOKEN_RE = re.compile(r"^[A-Za-z0-9_-]{16,40}$")

app = Flask(__name__, static_folder=os.path.join(BASE_DIR, "static"), static_url_path="")


class UserError(Exception):
    """Kesalahan yang pesannya aman ditampilkan ke pengguna."""


def err(message, code=400):
    return jsonify(error=message), code


# --------------------------------------------------------------------------
# Pembatas request sederhana (per IP, di memori)
# --------------------------------------------------------------------------
_hits = defaultdict(deque)


@app.before_request
def limit_requests():
    path = request.path
    if not path.startswith("/api/") or path.startswith("/api/file/") or path == "/api/preview":
        return None
    now = time.time()
    if len(_hits) > 5000:
        _hits.clear()
    q = _hits[request.remote_addr]
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= RATE_LIMIT:
        return err("Terlalu banyak permintaan. Tunggu sebentar lalu coba lagi.", 429)
    q.append(now)
    return None


# --------------------------------------------------------------------------
# Validasi URL dan host (cegah SSRF)
# --------------------------------------------------------------------------
def host_matches(host, suffixes):
    host = (host or "").lower()
    return any(host == s or host.endswith("." + s) for s in suffixes)


def check_page_url(url):
    p = urlparse(url or "")
    if p.scheme not in ("http", "https") or not host_matches(p.hostname, PAGE_HOSTS):
        raise UserError("Link tidak valid. Tempel link video atau foto dari tiktok.com.")
    return url


def is_public_host(host):
    if not STRICT_HOST_CHECK:
        return True
    try:
        infos = socket.getaddrinfo(host, 443, proto=socket.IPPROTO_TCP)
    except socket.gaierror:
        return False
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            return False
    return True


def extract_url(text):
    """Ambil link dari teks (pengguna sering menempel teks 'bagikan' lengkap)."""
    m = re.search(r"https?://[^\s]+", text or "")
    if not m:
        raise UserError("Tempel link TikTok yang lengkap, misalnya https://www.tiktok.com/@akun/video/123.")
    return m.group(0).rstrip(".,)")


def resolve_url(url):
    """Ikuti redirect link pendek (vm.tiktok.com) sambil memvalidasi tiap lompatan."""
    for _ in range(6):
        check_page_url(url)
        r = requests.get(url, headers=HEADERS, allow_redirects=False, timeout=15, stream=True)
        r.close()
        loc = r.headers.get("Location")
        if r.status_code in (301, 302, 303, 307, 308) and loc:
            url = urljoin(url, loc)
            continue
        return url.split("?")[0].split("#")[0]
    raise UserError("Link dialihkan terlalu banyak kali. Coba salin ulang linknya.")


def http_session():
    s = requests.Session()
    s.headers.update(HEADERS)
    if COOKIE_FILE and os.path.isfile(COOKIE_FILE):
        jar = MozillaCookieJar(COOKIE_FILE)
        jar.load(ignore_discard=True, ignore_expires=True)
        s.cookies.update(jar)
    return s


# --------------------------------------------------------------------------
# Cache info media (supaya /prepare tidak perlu ekstrak ulang)
# --------------------------------------------------------------------------
_cache = {}


def cache_get(url):
    item = _cache.get(url)
    if item and time.time() - item[0] < CACHE_TTL:
        return item[1]
    _cache.pop(url, None)
    return None


def cache_set(url, media):
    if len(_cache) > 100:
        for k in sorted(_cache, key=lambda key: _cache[key][0])[:20]:
            _cache.pop(k, None)
    _cache[url] = (time.time(), media)


# --------------------------------------------------------------------------
# Video: ambil daftar format lewat yt-dlp
# --------------------------------------------------------------------------
def ydl_opts(**extra):
    opts = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "socket_timeout": 20,
        "http_headers": {"User-Agent": UA, "Referer": "https://www.tiktok.com/"},
    }
    if COOKIE_FILE and os.path.isfile(COOKIE_FILE):
        opts["cookiefile"] = COOKIE_FILE
    if ANDROID:
        opts["cachedir"] = False  # jangan menulis cache yt-dlp di HP
    opts.update(extra)
    return opts


def codec_family(vcodec):
    v = (vcodec or "").lower()
    if v.startswith(("hev", "hvc", "h265", "bytevc1")):
        return "HEVC"
    if v.startswith(("avc", "h264")):
        return "H.264"
    return "" if v in ("", "none") else v.split(".")[0].upper()


def res_label(short_side):
    if short_side >= 2160:
        return "4K"
    if short_side >= 1440:
        return "2K"
    return f"{short_side}p"


def load_video(url):
    with yt_dlp.YoutubeDL(ydl_opts()) as ydl:
        info = ydl.extract_info(url, download=False)
    if not info:
        raise UserError("Video tidak ditemukan.")
    duration = info.get("duration") or 0
    if duration > MAX_VIDEO_SECONDS:
        raise UserError("Video terlalu panjang untuk diunduh lewat situs ini.")

    # Satu pilihan terbaik per kombinasi (resolusi, codec, watermark).
    best = {}
    for f in info.get("formats") or []:
        w, h = f.get("width"), f.get("height")
        if f.get("vcodec") == "none" or not f.get("url") or not w or not h:
            continue
        short = min(w, h)  # portrait 1080x1920 dilabeli 1080p, 2160x3840 dilabeli 4K
        wm = "watermark" in (f.get("format_note") or "").lower()
        fam = codec_family(f.get("vcodec"))
        score = f.get("tbr") or f.get("filesize") or 0
        key = (short, fam, wm)
        if key not in best or score > best[key]["score"]:
            best[key] = {
                "id": f["format_id"], "kind": "native", "label": res_label(short),
                "short": short, "width": w, "height": h, "codec": fam,
                "watermark": wm, "size": f.get("filesize") or f.get("filesize_approx"),
                "note": "", "score": score,
            }
    options = sorted(
        best.values(),
        key=lambda o: (-o["short"], o["watermark"], o["codec"] != "H.264", -o["score"]),
    )
    if not options:
        raise RuntimeError("yt-dlp tidak mengembalikan format video")

    # Tidak ada 4K asli? Tawarkan versi diperbesar (upscale) lewat ffmpeg.
    top = next((o for o in options if not o["watermark"]), options[0])
    if CAN_UPSCALE and top["short"] < 2160 and duration <= MAX_UPSCALE_SECONDS:
        portrait = top["height"] >= top["width"]
        ratio = top["height"] / top["width"] if portrait else top["width"] / top["height"]
        long_side = int(round(2160 * ratio / 2)) * 2
        w4k, h4k = (2160, long_side) if portrait else (long_side, 2160)
        options.insert(0, {
            "id": "upscale4k", "kind": "upscale", "label": "4K", "short": 2160,
            "width": w4k, "height": h4k, "codec": "H.264", "watermark": False,
            "size": None, "source": top["id"], "score": 0,
            "note": f"Diperbesar dari {top['short']}p",
        })

    return {
        "type": "video",
        "id": str(info.get("id") or ""),
        "title": (info.get("title") or "Video TikTok")[:140],
        "author": info.get("uploader") or info.get("creator") or "",
        "duration": duration,
        "thumbnail": info.get("thumbnail") or "",
        "options": options,
    }


# --------------------------------------------------------------------------
# Foto (slideshow): baca data JSON di halaman TikTok
# --------------------------------------------------------------------------
def load_photo(url):
    r = http_session().get(url, timeout=20)
    r.raise_for_status()
    m = re.search(
        r'<script[^>]+id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.*?)</script>', r.text, re.S
    )
    if not m:
        raise UserError(
            "Data postingan tidak bisa dibaca. TikTok mungkin memblokir server ini; "
            "coba pakai cookies (lihat README)."
        )
    scope = json.loads(m.group(1)).get("__DEFAULT_SCOPE__", {})
    item = ((scope.get("webapp.video-detail") or {}).get("itemInfo") or {}).get("itemStruct") or {}
    images = (item.get("imagePost") or {}).get("images") or []
    urls = []
    for im in images:
        candidates = (im.get("imageURL") or {}).get("urlList") or []
        src = next((u for u in candidates if u.startswith("https://")), None)
        if src:
            urls.append(src)
    if not urls:
        raise UserError("Tidak ada foto di postingan ini.")
    author = item.get("author")
    if isinstance(author, dict):
        author = author.get("uniqueId") or author.get("nickname")
    return {
        "type": "photo",
        "id": str(item.get("id") or ""),
        "title": (item.get("desc") or "Foto TikTok")[:140],
        "author": author or "",
        "thumbnail": urls[0],
        "images": urls,
    }


def load_media(url):
    cached = cache_get(url)
    if cached:
        return cached
    if "/photo/" in urlparse(url).path:
        media = load_photo(url)
    else:
        try:
            media = load_video(url)
        except Exception as video_err:  # bisa jadi ini postingan foto
            try:
                media = load_photo(url)
            except Exception:
                raise video_err
    media["page_url"] = url
    cache_set(url, media)
    return media


def public_media(m):
    out = {"type": m["type"], "url": m["page_url"], "title": m["title"], "author": m["author"]}
    if m["type"] == "video":
        keys = ("id", "kind", "label", "width", "height", "codec", "watermark", "size", "note")
        out["duration"] = m["duration"]
        out["options"] = [{k: o.get(k) for k in keys} for o in m["options"]]
    else:
        out["count"] = len(m["images"])
        out["upscale"] = Image is not None
    return out


# --------------------------------------------------------------------------
# Pengolahan file
# --------------------------------------------------------------------------
def safe_name(text):
    return re.sub(r"[^\w\-.]+", "_", text or "", flags=re.UNICODE).strip("._")[:80] or "tiktok"


def fetch_raw(src):
    p = urlparse(src)
    if p.scheme != "https" or not host_matches(p.hostname, CDN_HOSTS) or not is_public_host(p.hostname):
        raise UserError("Sumber gambar tidak diizinkan.")
    r = requests.get(src, headers=HEADERS, timeout=25, allow_redirects=False)
    r.raise_for_status()
    return r.content, r.headers.get("Content-Type", "image/jpeg").split(";")[0].strip().lower()


def upscale_image(data, target_long=3840):
    im = Image.open(io.BytesIO(data)).convert("RGB")
    w, h = im.size
    scale = target_long / max(w, h)
    if scale > 1:
        im = im.resize((round(w * scale), round(h * scale)), Image.LANCZOS)
        im = im.filter(ImageFilter.UnsharpMask(radius=2, percent=60, threshold=3))
    out = io.BytesIO()
    im.save(out, "JPEG", quality=95, subsampling=0)
    return out.getvalue()


def fetch_image(src, upscale):
    data, ctype = fetch_raw(src)
    ext = IMAGE_EXT.get(ctype, ".jpg")
    if upscale and Image is not None:
        try:
            return upscale_image(data), ".jpg"
        except Exception:
            app.logger.warning("Upscale foto gagal, memakai file asli", exc_info=True)
    return data, ext


def upscale_video(src, dst, opt):
    if not FFMPEG:
        raise UserError("ffmpeg belum terpasang di server, jadi video tidak bisa diperbesar.")
    vf = f"scale={opt['width']}:{opt['height']}:flags=lanczos,unsharp=5:5:0.7:5:5:0.0"
    cmd = [
        FFMPEG, "-y", "-loglevel", "error", "-i", src, "-vf", vf,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p",
        "-c:a", "copy", "-movflags", "+faststart", dst,
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True, timeout=900)
    except subprocess.TimeoutExpired:
        raise UserError("Proses memperbesar ke 4K terlalu lama. Coba video yang lebih pendek.")
    except subprocess.CalledProcessError as e:
        app.logger.error("ffmpeg gagal: %s", e.stderr.decode(errors="ignore"))
        raise RuntimeError("ffmpeg gagal")


def make_video(media, option_id, jobdir):
    opt = next((o for o in media["options"] if o["id"] == option_id), None)
    if not opt:
        raise UserError("Pilihan kualitas tidak ditemukan. Cek link sekali lagi.")
    source_id = opt.get("source") or opt["id"]
    with yt_dlp.YoutubeDL(ydl_opts(
        format=source_id,
        outtmpl=os.path.join(jobdir, "src.%(ext)s"),
        merge_output_format="mp4",
        overwrites=True,
    )) as ydl:
        ydl.download([media["page_url"]])
    files = [f for f in os.listdir(jobdir) if f.startswith("src.")]
    if not files:
        raise RuntimeError("Unduhan video gagal")
    src = os.path.join(jobdir, files[0])
    base = safe_name(f"{media['author'] or 'tiktok'}_{media['id']}")
    if opt["kind"] == "upscale":
        name = f"{base}_4K-diperbesar.mp4"
        if NATIVE_UPSCALE:
            # Aplikasi Android mengambil file sumber ini lalu memperbesarnya sendiri.
            return src, name, {"native_upscale": {"width": opt["width"], "height": opt["height"]}}
        dst = os.path.join(jobdir, "out.mp4")
        upscale_video(src, dst, opt)
        os.remove(src)
        return dst, name, {}
    return src, f"{base}_{opt['label']}{os.path.splitext(src)[1] or '.mp4'}", {}


def make_photo_file(media, body, jobdir):
    upscale = bool(body.get("upscale")) and Image is not None
    base = safe_name(f"{media['author'] or 'tiktok'}_{media['id']}")
    suffix = "_4K" if upscale else ""
    if body.get("index") is not None:
        try:
            i = int(body["index"])
            src = media["images"][i]
        except (ValueError, IndexError, TypeError):
            raise UserError("Foto tidak ditemukan.")
        data, ext = fetch_image(src, upscale)
        path = os.path.join(jobdir, "photo" + ext)
        with open(path, "wb") as fh:
            fh.write(data)
        return path, f"{base}_{i + 1}{suffix}{ext}", {}
    path = os.path.join(jobdir, "photos.zip")
    with zipfile.ZipFile(path, "w", zipfile.ZIP_STORED) as z:
        for i, src in enumerate(media["images"]):
            data, ext = fetch_image(src, upscale)
            z.writestr(f"{base}_{i + 1}{suffix}{ext}", data)
    return path, f"{base}_foto{suffix}.zip", {}


def cleanup_jobs():
    now = time.time()
    for entry in os.scandir(WORK_DIR):
        try:
            if entry.is_dir() and now - entry.stat().st_mtime > JOB_TTL:
                shutil.rmtree(entry.path, ignore_errors=True)
        except OSError:
            pass


# --------------------------------------------------------------------------
# Route
# --------------------------------------------------------------------------
@app.get("/")
def index():
    if INDEX_HTML is not None:
        return Response(INDEX_HTML, mimetype="text/html")
    return send_from_directory(app.static_folder, "index.html")


@app.get("/health")
def health():
    return "ok"


@app.post("/api/info")
def api_info():
    body = request.get_json(silent=True) or {}
    try:
        url = resolve_url(extract_url(body.get("url", "")))
        media = load_media(url)
    except UserError as e:
        return err(str(e), 400)
    except requests.RequestException:
        return err("Tidak bisa menghubungi TikTok dari server. Coba lagi nanti.", 502)
    except yt_dlp.utils.DownloadError as e:
        app.logger.warning("yt-dlp: %s", e)
        return err("TikTok menolak permintaan, atau postingan ini privat/sudah dihapus.", 502)
    except Exception:
        app.logger.exception("Gagal mengambil info")
        return err("Gagal membaca postingan ini. Coba lagi nanti.", 502)
    return jsonify(public_media(media))


@app.post("/api/prepare")
def api_prepare():
    body = request.get_json(silent=True) or {}
    cleanup_jobs()
    token = secrets.token_urlsafe(16)
    jobdir = os.path.join(WORK_DIR, token)
    os.makedirs(jobdir)
    try:
        url = check_page_url(body.get("url", ""))
        media = load_media(url)
        if media["type"] == "video":
            path, name, extra = make_video(media, body.get("format"), jobdir)
        else:
            path, name, extra = make_photo_file(media, body, jobdir)
        meta = {
            "file": os.path.basename(path),
            "name": name,
            "mimetype": mimetypes.guess_type(name)[0] or "application/octet-stream",
        }
        with open(os.path.join(jobdir, "meta.json"), "w", encoding="utf-8") as fh:
            json.dump(meta, fh)
    except UserError as e:
        shutil.rmtree(jobdir, ignore_errors=True)
        return err(str(e), 400)
    except Exception:
        shutil.rmtree(jobdir, ignore_errors=True)
        app.logger.exception("Gagal menyiapkan file")
        return err("Gagal menyiapkan file. Cek link lagi, atau coba beberapa saat lagi.", 502)
    return jsonify(download=f"/api/file/{token}", name=name, **extra)


@app.get("/api/file/<token>")
def api_file(token):
    if not TOKEN_RE.match(token):
        return err("Berkas tidak ditemukan.", 404)
    jobdir = os.path.join(WORK_DIR, token)
    meta_path = os.path.join(jobdir, "meta.json")
    if not os.path.isfile(meta_path):
        return err("Berkas sudah kedaluwarsa. Buat ulang dari halaman utama.", 404)
    with open(meta_path, encoding="utf-8") as fh:
        meta = json.load(fh)
    return send_file(
        os.path.join(jobdir, meta["file"]),
        as_attachment=True,
        download_name=meta["name"],
        mimetype=meta["mimetype"],
    )


@app.get("/api/preview")
def api_preview():
    try:
        url = check_page_url(request.args.get("url", ""))
        media = load_media(url)
        which = request.args.get("i", "cover")
        src = media["images"][int(which)] if media["type"] == "photo" and which != "cover" else media["thumbnail"]
        data, ctype = fetch_raw(src)
    except Exception:
        return Response(status=404)
    return Response(data, content_type=ctype, headers={"Cache-Control": "private, max-age=600"})


if __name__ == "__main__":
    print(f"ffmpeg: {'ada' if FFMPEG else 'TIDAK ADA (upscale video ke 4K nonaktif)'}")
    print(f"Pillow: {'ada' if Image else 'TIDAK ADA (upscale foto ke 4K nonaktif)'}")
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), threaded=True)
