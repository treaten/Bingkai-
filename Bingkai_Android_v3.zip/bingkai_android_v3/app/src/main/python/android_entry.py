"""Dipanggil dari Kotlin (MainActivity) lewat Chaquopy untuk menyalakan server lokal."""
import os
import threading

os.environ["BINGKAI_ANDROID"] = "1"  # harus diset sebelum `import app`

import app as bingkai  # noqa: E402

_lock = threading.Lock()
_started = False


def start(port, html):
    """Nyalakan Flask di 127.0.0.1:<port>. Aman dipanggil berkali-kali."""
    global _started
    with _lock:
        if _started:
            return
        _started = True
    bingkai.INDEX_HTML = html
    threading.Thread(
        target=lambda: bingkai.app.run(
            host="127.0.0.1", port=int(port), threaded=True, use_reloader=False
        ),
        daemon=True,
    ).start()
